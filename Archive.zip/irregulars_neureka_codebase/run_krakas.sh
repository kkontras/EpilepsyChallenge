

#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --lr 0.0001 --wd 0.001  --bs 64
python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --lr 0.001 --wd 0.0001 --bs 64
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --lr 0.001 --wd 0.001 --bs 64