
#python3 main.py --config ./configs/neureka.json --default_config ./configs/default_config_tuh.json
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuh.json --rsz 0.5 --bs 64 --post_validate
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuh.json --rsz 0.2 --bs 64
#
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_sz2.json --rsz 0.5 --bs 64



#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.0001 --wd 0.00001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.0001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.0001 --wd 0.001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.001 --wd 0.00001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.001 --wd 0.001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.0001 --wd 0.00001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.0001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.0001 --wd 0.001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.001 --wd 0.00001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.001 --wd 0.001 --print_results
#
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.0001 --wd 0.00001 --print_results
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.0001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.0001 --wd 0.001 --print_results
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.001 --wd 0.00001 --print_results
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.001 --wd 0.001 --print_results
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.0001 --wd 0.00001 --print_results
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.0001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.0001 --wd 0.001 --print_results
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.001 --wd 0.00001 --print_results
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.001 --wd 0.001 --print_results
#
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.0001 --wd 0.00001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.0001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.0001 --wd 0.001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.001 --wd 0.00001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.001 --wd 0.001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.0001 --wd 0.00001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.0001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.0001 --wd 0.001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.001 --wd 0.00001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.001 --wd 0.001 --print_results
#
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.0001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.00001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.0001 --wd 0 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 32 --lr 0.0001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 32 --lr 0.0001 --wd 0 --print_results
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.001 --wd 0.0001 --print_results #becassine
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.00001 --wd 0.0001 --print_results #augustijn
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.0001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.0001 --wd 0 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.0001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.00001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.0001 --wd 0 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 32 --lr 0.0001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 32 --lr 0.0001 --wd 0 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.001 --wd 0.001 --print_results #asterie
##
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.001 --wd 0.001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.001 --wd 0.0001 --print_results #krakas
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.0001 --wd 0.0001 --print_results
python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.0001 --wd 0.001 --post_validate #brigand
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.00001 --wd 0.0001 --print_results #deanston
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.0001 --wd 0 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.0001 --wd 0.0001 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 64 --lr 0.0001 --wd 0 --print_results
#python3 main.py --config ./configs/neureka_rawwiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 64 --lr 0.001 --wd 0.001 --print_results



#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.001 --wd 0.0001 #odie
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.0001 --wd 0.0001 #timmemrmans
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.00001 --wd 0.0001 #gohan
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.0001 --wd 0 #nounou
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 32 --lr 0.0001 --wd 0.0001
#python3 main.py --config ./configs/unet_raw.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 32 --lr 0.0001 --wd 0 #asterie
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.0001 --wd 0.0001 #becassine
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.5 --bs 32 --lr 0.0001 --wd 0 #augustijn
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 32 --lr 0.0001 --wd 0.0001
#python3 main.py --config ./configs/unet_wiener.json --default_config ./configs/default_config_tuhsz2.json --rsz 0.2 --bs 32 --lr 0.0001 --wd 0

#python3 main.py --config ./configs/neureka.json --default_config ./configs/default_config_tuhsz2.json